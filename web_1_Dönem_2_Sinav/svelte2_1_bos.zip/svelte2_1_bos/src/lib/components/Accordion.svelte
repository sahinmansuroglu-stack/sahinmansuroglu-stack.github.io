<script>
    export let items = [
        { title: "Accordion Item #1", content: "Content for item #1" },
        { title: "Accordion Item #2", content: "Content for item #2" },
        { title: "Accordion Item #3", content: "Content for item #3" },
    ];

    let openIndex = 0; // Default open item

    function toggle(index) {
        if (openIndex === index) {
            openIndex = -1; // Close if already open
        } else {
            openIndex = index;
        }
    }
</script>

<div class="accordion" id="accordionExample">
    {#each items as item, index}
        <div class="accordion-item">
            <h2 class="accordion-header" id="heading{index}">
                <button
                    class="accordion-button {openIndex === index
                        ? ''
                        : 'collapsed'}"
                    type="button"
                    on:click={() => toggle(index)}
                    data-bs-toggle="collapse"
                    aria-expanded={openIndex === index}
                >
                    {item.title}
                </button>
            </h2>
            <div
                id="collapse{index}"
                class="accordion-collapse collapse {openIndex === index
                    ? 'show'
                    : ''}"
                aria-labelledby="heading{index}"
                data-bs-parent="#accordionExample"
            >
                <div class="accordion-body">
                    {item.content}
                </div>
            </div>
        </div>
    {/each}
</div>
