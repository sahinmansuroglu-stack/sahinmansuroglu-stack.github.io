<script>
    /**
     * @typedef {Object} Props
     * @property {string} [type]
     * @property {string} [message]
     * @property {() => void} [onclose]
     */

    /** @type {Props} */
    let {
        type = "primary",
        message = "A simple alert—check it out!",
        onclose,
    } = $props();

    let visible = $state(true);

    export function close() {
        visible = false;
        onclose?.();
    }
</script>

{#if visible}
    <div class="alert alert-{type} alert-dismissible fade show" role="alert">
        {message}
        <button
            type="button"
            class="btn-close"
            aria-label="Close"
            onclick={close}
        ></button>
    </div>
{/if}
