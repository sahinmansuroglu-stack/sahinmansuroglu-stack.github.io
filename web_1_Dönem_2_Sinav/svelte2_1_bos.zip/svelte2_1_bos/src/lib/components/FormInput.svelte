<script>
    export let label = "Label";
    export let type = "text";
    export let placeholder = "";
    export let value = "";
    export let id = "input-" + Math.random().toString(36).substr(2, 9);
</script>

<div class="mb-3">
    <label for={id} class="form-label">{label}</label>
    <input {type} class="form-control" {id} {placeholder} bind:value />
    <div class="form-text">
        <slot />
    </div>
</div>
