<script>
    export let brand = "My App";
    export let links = [
        { text: "Home", href: "#" },
        { text: "Features", href: "#" },
        { text: "Pricing", href: "#" },
    ];
</script>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4 rounded">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">{brand}</a>
        <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
        >
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                {#each links as link}
                    <li class="nav-item">
                        <a class="nav-link" aria-current="page" href={link.href}
                            >{link.text}</a
                        >
                    </li>
                {/each}
            </ul>
        </div>
    </div>
</nav>
