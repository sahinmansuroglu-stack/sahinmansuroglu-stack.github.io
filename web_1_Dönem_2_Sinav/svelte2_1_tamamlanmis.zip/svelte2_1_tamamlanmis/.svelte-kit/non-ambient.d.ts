
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	export interface AppTypes {
		RouteId(): "/" | "/accordion" | "/alert" | "/badge" | "/card" | "/form" | "/functional-app" | "/modal" | "/navbar" | "/spinner";
		RouteParams(): {
			
		};
		LayoutParams(): {
			"/": Record<string, never>;
			"/accordion": Record<string, never>;
			"/alert": Record<string, never>;
			"/badge": Record<string, never>;
			"/card": Record<string, never>;
			"/form": Record<string, never>;
			"/functional-app": Record<string, never>;
			"/modal": Record<string, never>;
			"/navbar": Record<string, never>;
			"/spinner": Record<string, never>
		};
		Pathname(): "/" | "/accordion" | "/accordion/" | "/alert" | "/alert/" | "/badge" | "/badge/" | "/card" | "/card/" | "/form" | "/form/" | "/functional-app" | "/functional-app/" | "/modal" | "/modal/" | "/navbar" | "/navbar/" | "/spinner" | "/spinner/";
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/favicon.svg" | "/robots.txt" | string & {};
	}
}