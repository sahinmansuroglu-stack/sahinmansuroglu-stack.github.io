<script>
    export let color = "primary"; // primary, secondary, success, danger, warning, info, light, dark
    export let type = "border"; // border, grow
    export let size = ""; // sm, or empty for normal
</script>

<div
    class="spinner-{type} text-{color} {size
        ? 'spinner-' + type + '-' + size
        : ''}"
    role="status"
>
    <span class="visually-hidden">Loading...</span>
</div>
