<script>
    export let color = "primary"; // primary, secondary, success, danger, warning, info, light, dark
    export let pill = false;
</script>

<span class="badge {pill ? 'rounded-pill' : ''} text-bg-{color}">
    <slot />
</span>
