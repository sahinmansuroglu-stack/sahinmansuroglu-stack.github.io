<script>
    /**
     * @typedef {Object} Props
     * @property {string} [title]
     * @property {boolean} [open]
     * @property {import('svelte').Snippet} [children]
     * @property {() => void} [onclose]
     * @property {() => void} [onsave]
     */

    /** @type {Props} */
    let {
        title = "Modal title",
        open = $bindable(false),
        children,
        onclose,
        onsave,
    } = $props();

    function handleClose() {
        open = false;
        onclose?.();
    }

    function handleSave() {
        onsave?.();
        handleClose();
    }
</script>

{#if open}
    <div
        class="modal fade show"
        style="display: block; background-color: rgba(0,0,0,0.5);"
        tabindex="-1"
        role="dialog"
        aria-modal="true"
    >
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">{title}</h5>
                    <button
                        type="button"
                        class="btn-close"
                        aria-label="Close"
                        onclick={handleClose}
                    ></button>
                </div>
                <!-- svelte-ignore a11y_click_events_have_key_events -->
                <div class="modal-body">
                    {@render children?.()}
                </div>
                <div class="modal-footer">
                    <button
                        type="button"
                        class="btn btn-secondary"
                        onclick={handleClose}>Close</button
                    >
                    <button
                        type="button"
                        class="btn btn-primary"
                        onclick={handleSave}>Save changes</button
                    >
                </div>
            </div>
        </div>
    </div>
{/if}
