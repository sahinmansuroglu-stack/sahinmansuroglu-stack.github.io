<script>
    /**
     * @typedef {Object} Props
     * @property {string} [title]
     * @property {string} [imageUrl]
     * @property {string} [buttonText]
     * @property {import('svelte').Snippet} [children]
     * @property {(e: MouseEvent) => void} [onclick]
     */

    /** @type {Props} */
    let {
        title = "Card Title",
        imageUrl = "https://via.placeholder.com/150",
        buttonText = "Go somewhere",
        children,
        onclick,
    } = $props();

    /** @param {MouseEvent} e */
    function handleClick(e) {
        e.preventDefault();
        onclick?.(e);
    }
</script>

<div class="card" style="width: 18rem;">
    <img src={imageUrl} class="card-img-top" alt={title} />
    <div class="card-body">
        <h5 class="card-title">{title}</h5>
        <div class="card-text">
            {@render children?.()}
        </div>
        <a href="#" class="btn btn-primary" onclick={handleClick} role="button"
            >{buttonText}</a
        >
    </div>
</div>
