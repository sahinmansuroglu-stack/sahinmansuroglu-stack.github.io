<script>
  import Navbar from "$lib/components/Navbar.svelte";
  import { resolve } from "$app/paths";
</script>

<div class="container py-5">
  <a href={resolve("/")} class="btn btn-outline-secondary mb-4"
    >&laquo; Ana Sayfaya Dön</a
  >

  <h1 class="mb-4">Navbar Component</h1>
  <p class="lead">Bootstrap 5 tabanlı, responsif bir navigasyon çubuğu.</p>

  <div class="card mb-4">
    <div class="card-header">Önizleme</div>
    <div class="card-body">
      <Navbar
        brand="Okul Portalı"
        links={[
          { text: "Ana Sayfa", href: "#" },
          { text: "Dersler", href: "#" },
          { text: "Profil", href: "#" },
        ]}
      />
    </div>
  </div>
</div>
