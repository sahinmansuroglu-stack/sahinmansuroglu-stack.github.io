<script>
  import Alert from "$lib/components/Alert.svelte";
  import { resolve } from "$app/paths";
</script>

<div class="container py-5">
  <a href={resolve("/")} class="btn btn-outline-secondary mb-4"
    >&laquo; Ana Sayfaya Dön</a
  >

  <h1 class="mb-4">Alert Component</h1>
  <p class="lead">
    Kullanıcı geri bildirimleri için kullanılan uyarı kutuları.
  </p>

  <div class="card mb-4">
    <div class="card-header">Önizleme</div>
    <div class="card-body">
      <Alert type="success" message="İşlem başarıyla tamamlandı!" />
      <Alert type="danger" message="Bir hata oluştu!" />
      <Alert type="warning" message="Lütfen bilgilerinizi kontrol edin." />
    </div>
  </div>
</div>
