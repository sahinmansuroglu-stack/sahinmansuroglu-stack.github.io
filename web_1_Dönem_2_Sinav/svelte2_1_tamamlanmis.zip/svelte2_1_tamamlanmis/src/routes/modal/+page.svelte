<script>
  import Modal from "$lib/components/Modal.svelte";
  import { resolve } from "$app/paths";

  let isOpen = false;
</script>

<div class="container py-5">
  <a href={resolve("/")} class="btn btn-outline-secondary mb-4"
    >&laquo; Ana Sayfaya Dön</a
  >

  <h1 class="mb-4">Modal Component</h1>
  <p class="lead">Kullanıcı etkileşimi için açılır pencere (lightbox).</p>

  <div class="card mb-4">
    <div class="card-header">Önizleme</div>
    <div class="card-body">
      <button class="btn btn-primary" on:click={() => (isOpen = true)}>
        Örnek Modalı Aç
      </button>

      <Modal title="Onay Penceresi" bind:open={isOpen}>
        <p>Bu modali <code>bind:open</code> özelliği ile kontrol ediyoruz.</p>
        <p>İçeriği slot ile gönderiyoruz.</p>
      </Modal>
    </div>
  </div>
</div>
