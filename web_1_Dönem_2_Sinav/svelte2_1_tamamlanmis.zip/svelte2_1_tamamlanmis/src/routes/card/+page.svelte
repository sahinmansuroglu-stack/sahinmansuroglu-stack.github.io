<script>
  import Card from "$lib/components/Card.svelte";
  import { resolve } from "$app/paths";
  import cardImage from "$lib/images/card-image.png";
</script>

<div class="container py-5">
  <a href={resolve("/")} class="btn btn-outline-secondary mb-4"
    >&laquo; Ana Sayfaya Dön</a
  >

  <h1 class="mb-4">Card Component</h1>
  <p class="lead">Esnek içerik yönetimi sağlayan kart bileşeni.</p>

  <div class="card mb-4">
    <div class="card-header">Önizleme</div>
    <div class="card-body d-flex justify-content-center">
      <Card
        title="Öğrenci Bilgisi"
        imageUrl={cardImage}
        buttonText="Profili Gör"
      >
        <p>Bu alan <strong>slot</strong> üzerinden doldurulmuştur.</p>
        <p>İstediğiniz HTML içeriğini buraya ekleyebilirsiniz.</p>
      </Card>
    </div>
  </div>
</div>
