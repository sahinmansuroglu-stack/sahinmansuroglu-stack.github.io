<script>
  import Accordion from "$lib/components/Accordion.svelte";
  import { resolve } from "$app/paths";

  const items = [
    { title: "Bölüm 1: Giriş", content: "Svelte harika bir frameworktür." },
    {
      title: "Bölüm 2: Kurulum",
      content: "npm create svelte@latest my-app komutu ile kurulur.",
    },
    {
      title: "Bölüm 3: Bileşenler",
      content: ".svelte uzantılı dosyalar bileşenlerdir.",
    },
  ];
</script>

<div class="container py-5">
  <a href={resolve("/")} class="btn btn-outline-secondary mb-4"
    >&laquo; Ana Sayfaya Dön</a
  >

  <h1 class="mb-4">Accordion Component</h1>
  <p class="lead">
    Çoklu içeriği yer kaplamadan sunmak için kullanılan akordiyon menü.
  </p>

  <div class="card mb-4">
    <div class="card-header">Önizleme</div>
    <div class="card-body">
      <Accordion {items} />
    </div>
  </div>
</div>
