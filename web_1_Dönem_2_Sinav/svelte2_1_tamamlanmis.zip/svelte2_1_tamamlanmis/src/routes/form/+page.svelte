<script>
    import FormInput from "$lib/components/FormInput.svelte";
    import { resolve } from "$app/paths";

    let email = "";
    let password = "";
</script>

<div class="container py-5">
    <a href={resolve("/")} class="btn btn-outline-secondary mb-4"
        >&laquo; Ana Sayfaya Dön</a
    >

    <h1 class="mb-4">Form Component</h1>
    <p class="lead">
        Bootstrap stillerini kullanan yeniden kullanılabilir form bileşeni.
    </p>

    <div class="card mb-4">
        <div class="card-header">Önizleme</div>
        <div class="card-body">
            <form>
                <FormInput
                    label="E-posta Adresi"
                    type="email"
                    placeholder="name@example.com"
                    bind:value={email}
                >
                    E-postanızı kimseyle paylaşmayacağız.
                </FormInput>

                <FormInput
                    label="Şifre"
                    type="password"
                    placeholder="Şifreniz"
                    bind:value={password}
                />
            </form>

            <hr />
            <h5>Girilen Değerler:</h5>
            <p><strong>Email:</strong> {email}</p>
            <p><strong>Şifre:</strong> {password}</p>
        </div>
    </div>
</div>
