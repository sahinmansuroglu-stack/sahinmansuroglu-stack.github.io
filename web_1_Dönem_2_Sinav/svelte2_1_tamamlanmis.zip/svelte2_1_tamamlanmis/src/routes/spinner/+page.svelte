<script>
    import Spinner from "$lib/components/Spinner.svelte";
    import { resolve } from "$app/paths";
</script>

<div class="container py-5">
    <a href={resolve("/")} class="btn btn-outline-secondary mb-4"
        >&laquo; Ana Sayfaya Dön</a
    >

    <h1 class="mb-4">Spinner Component</h1>
    <p class="lead">
        Yükleniyor durumlarını göstermek için kullanılan animasyonlu bileşen.
    </p>

    <div class="card mb-4">
        <div class="card-header">Önizleme</div>
        <div class="card-body">
            <h5>Standart Spinnerlar</h5>
            <div class="d-flex gap-3 mb-4">
                <Spinner color="primary" />
                <Spinner color="secondary" />
                <Spinner color="success" />
                <Spinner color="danger" />
                <Spinner color="warning" />
                <Spinner color="info" />
                <Spinner color="dark" />
            </div>

            <h5>Growing Spinnerlar</h5>
            <div class="d-flex gap-3 mb-4">
                <Spinner type="grow" color="primary" />
                <Spinner type="grow" color="success" />
                <Spinner type="grow" color="danger" />
            </div>

            <h5>Boyutlar</h5>
            <div class="d-flex gap-3 align-items-center">
                <Spinner size="sm" color="primary" />
                <Spinner color="primary" />
            </div>
        </div>
    </div>
</div>
