<script>
    import { fade } from "svelte/transition";
    import FormInput from "$lib/components/FormInput.svelte";
    import Card from "$lib/components/Card.svelte";
    import Modal from "$lib/components/Modal.svelte";
    import Alert from "$lib/components/Alert.svelte";
    import Spinner from "$lib/components/Spinner.svelte";
    import Badge from "$lib/components/Badge.svelte";
    import cardImage from "$lib/images/card-image.png";


    let ogeler = $state([]);
    let baslik = $state("");
    let aciklama = $state("");
    let yukleniyor = $state(false);

    let hata = $state(null);

    let basari = $state(null);
    let silmeModaliniGoster = $state(false);

    let silinecekOge = $state(null);

    function ogeEkle() {
        hata = null;
        basari = null;

        if (!baslik.trim() || !aciklama.trim()) {
            hata = "Lütfen tüm alanları doldurunuz.";
            return;
        }

        yukleniyor = true;
        // 2 saniye bekle ve işlemi tamamla
        setTimeout(islemiTamamla, 2000);
    }

    function islemiTamamla() {
        ogeler = [...ogeler, { id: Date.now(), baslik, aciklama }];
        baslik = "";
        aciklama = "";
        yukleniyor = false;
        basari = "Öğe başarıyla eklendi!";

        // Başarı mesajını 3 saniye sonra temizle
        setTimeout(() => {
            basari = null;
        }, 3000);
    }

    function silmeIstegi(oge) {
        silinecekOge = oge;
        silmeModaliniGoster = true;
    }

    function silmeyiOnayla() {
        if (silinecekOge) {
            const currentOge = silinecekOge;
            ogeler = ogeler.filter((i) => i.id !== currentOge.id);
            silinecekOge = null;
        }
    }
</script>

<div class="container mt-5">
    <h1>İşlevsel Uygulama Demo</h1>
    <p class="mb-4">
        Bu sayfa refaktör edilmiş bileşenleri kullanır (Svelte 5 Runes).
    </p>

    <!-- Hata/Başarı Bildirimleri -->
    <div class="mb-3">
        {#if hata}
            <Alert type="danger" message={hata} onclose={() => (hata = null)} />
        {/if}
        {#if basari}
            <Alert
                type="success"
                message={basari}
                onclose={() => (basari = null)}
            />
        {/if}
    </div>

    <!-- Giriş Formu -->
    <div class="card p-4 mb-5 shadow-sm">
        <h4>Yeni Ekle</h4>
        <FormInput
            label="Başlık"
            placeholder="Örn: Alışveriş"
            bind:value={baslik}
        />
        <FormInput
            label="Açıklama"
            placeholder="Örn: Süt ve yumurta al"
            bind:value={aciklama}
        />

        <div class="mt-3">
            {#if yukleniyor}
                <div class="d-flex align-items-center">
                    <Spinner type="border" color="primary" size="sm" />
                    <span class="ms-2">Ekleniyor...</span>
                </div>
            {:else}
                <button class="btn btn-success" onclick={ogeEkle}>
                    Ekle
                </button>
            {/if}
        </div>
    </div>

    <!-- Liste -->
    <div class="row">
        {#each ogeler as oge (oge.id)}
            <div class="col-md-4 mb-4">
                <Card
                    title={oge.baslik}
                    imageUrl={cardImage}
                    buttonText="Sil"
                    onclick={() => silmeIstegi(oge)}
                >
                    {oge.aciklama}
                    <div class="mt-2">
                        <Badge color="info">Yeni</Badge>
                    </div>
                </Card>
            </div>
        {/each}
        {#if ogeler.length === 0}
            <p class="text-muted text-center">Henüz eklenmiş bir öğe yok.</p>
        {/if}
    </div>
</div>

<!-- Silme Onay Modalı -->
<Modal
    title="Silme Onayı"
    bind:open={silmeModaliniGoster}
    onsave={silmeyiOnayla}
>
    <p>Bu öğeyi silmek istediğinize emin misiniz?</p>
    <p class="text-danger fw-bold">{silinecekOge ? silinecekOge.baslik : ""}</p>
    <p class="small text-muted">Bu işlem geri alınamaz.</p>
</Modal>
