<script>
    import Badge from "$lib/components/Badge.svelte";
    import { resolve } from "$app/paths";
</script>

<div class="container py-5">
    <a href={resolve("/")} class="btn btn-outline-secondary mb-4"
        >&laquo; Ana Sayfaya Dön</a
    >

    <h1 class="mb-4">Badge Component</h1>
    <p class="lead">Etiketleme ve sayım için kullanılan küçük rozetler.</p>

    <div class="card mb-4">
        <div class="card-header">Önizleme</div>
        <div class="card-body">
            <h5>Renkler</h5>
            <div class="d-flex gap-2 mb-4 flex-wrap">
                <Badge color="primary">Primary</Badge>
                <Badge color="secondary">Secondary</Badge>
                <Badge color="success">Success</Badge>
                <Badge color="danger">Danger</Badge>
                <Badge color="warning">Warning</Badge>
                <Badge color="info">Info</Badge>
                <Badge color="light">Light</Badge>
                <Badge color="dark">Dark</Badge>
            </div>

            <h5>Pill (Yuvarlak) Rozetler</h5>
            <div class="d-flex gap-2 mb-4 flex-wrap">
                <Badge pill color="primary">Primary</Badge>
                <Badge pill color="success">Success</Badge>
                <Badge pill color="danger">Danger</Badge>
            </div>

            <h5>İçerik İçinde Kullanım</h5>
            <h3>Başlık <Badge color="secondary">Yeni</Badge></h3>
            <h4>Başlık <Badge color="secondary">Yeni</Badge></h4>
            <h5>Başlık <Badge color="secondary">Yeni</Badge></h5>

            <button type="button" class="btn btn-primary mt-3">
                Bildirimler <Badge color="secondary">4</Badge>
            </button>
        </div>
    </div>
</div>
